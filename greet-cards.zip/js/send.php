<?

        $to = 'bon-evgenia@yandex.ru'; //Почта получателя, через запятую можно указать сколько угодно адресов
        $subject = 'Обратный звонок'; //Загаловок сообщения
        $message = 'рор'; //Текст нащего сообщения можно использовать HTML теги
        $headers = "Content-type: text/html; charset=utf-8 \r\n"; //Кодировка письма
        $headers = "From: Отправитель <bon-evgenia@ya.ru>\r\n"; //Наименование и почта отправителя
        mail($to, $subject, $message, ); //Отправка письма с помощью функции mail
?>
