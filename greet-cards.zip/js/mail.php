<?
mail( "chitsvarina@gmail.com", "Тема письма", "Имя отправителя: $fio\nE-mail: $email\nОставил сообщение:\n$mess" );
?>
